# Terms of Service

---

## Information

It is assumed that if you use VerifyME, you have read and accepted the
discord bot's terms of service. Your right to use VerifyME will be taken
away if you disagree with the terms of service.

## Uses

Advertising inappropriately without authorization and using it for any
reasons that are outside the Terms of Service are explicitly forbidden by
VerifyME. Use of VerifyME may be terminated from your server if you
attempt to obtain the bot's token or take any other action that could harm
the bot.

## Copyright

You are not permitted to copy the bot code and support server as doing so
will result in the removal of VerifyME from your server. Additionally, you
are not permitted to claim that VerifyME is your bot, as doing so will
result in copyright-related legal penalties.
The <a href="https://verifymebot.xyz">VerifyME website</a>{" "}
(https://verifymebot.xyz/) (https://verifymebot.vercel.app) is licensed
under the MIT License and can be found open-source on
      <a href="https://github.com/">GitHub</a> (https://github.com/) <a href="https://github.com/myferr/verifyme-website">here</a> (https://github.com/myferr/verifyme-website)


# Uptime

VerifyME is currently being actively developed; it could be switched off
at any time or continue to function normally. You must recognize that
whatever happens to the bot depends on a number of different
circumstances.

## Note

Spreading misleading reviews in an effort to lower the bot's rating will
not be tolerated. Not to mention, The terms of service are susceptible to
change at any time, thus it is your responsibility to review them
frequently if you use VerifyME.